// :: ROUTES TIL admin arrangementer siden

module.exports = (app) => {
    // ====================================================================================================
    // ================================================ RENDER ============================================
    // ====================================================================================================


    // route til at render admin arrangementer side
    app.get('/admin/admin_arrangementer', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole;
        console.log(userRole)
        console.log(userRole != 'admin')
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var alle_arr = `SELECT arrangementer.id, arrangementer.navn, arrangementer.dato, arrangementer.tekst, arrangementer.billede FROM arrangementer`;
            db.query(alle_arr, function (err, allearrs) {
                res.render('pages/admin_arrangementer', {
                    allearrs: allearrs
                });
            });
        }
    });

    // route til at render admin bådpark oprettelses side
    app.get('/admin/admin_arrangementer_opret', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var fejlbesked = ""
            var godkendtbesked = ""
            res.render('pages/admin_arrangementer_opret', {
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
            console.log(fejlbesked)
        }
    });

    // ====================================================================================================
    // ================================================= POST =============================================
    // ====================================================================================================


    // route til at oprette et produkt + Validering
    app.post('/admin_arrangementer_opret', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        var alertopret = null
        var navn = req.body.navn
        var dato = req.body.dato
        var tekst = req.body.tekst
        var billede = req.body.billede

        // Validering
        if (navn == "" || dato == "" || tekst == "" || billede == "") {
            fejlbesked = "Formular ikke helt udfyldt!"
            res.render('pages/admin_arrangementer_opret', {
                alertopret: alertopret,
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
        } else {
            db.query("insert into arrangementer set navn = ?, dato = ?, tekst = ?, billede = ?", [navn, dato, tekst, billede], (err) => {
                if (err) {
                    console.log(err)
                } else {
                    godkendtbesked = "Arrangement oprettet!"
                    res.render('pages/admin_arrangementer_opret', {
                        fejlbesked: fejlbesked,
                        godkendtbesked: godkendtbesked
                    });

                }
            })

        }
    })


    // ====================================================================================================
    // ========================================== UPDATE / PUT ============================================
    // ====================================================================================================


    // route til at render update side og fetche et arrangement med et specifikt id via url'en
    app.get('/arr/update/:id', function (req, res) {
        var id = req.params.id
        var upd_prod = `SELECT arrangementer.id, arrangementer.navn, arrangementer.dato, arrangementer.tekst, arrangementer.billede FROM arrangementer where arrangementer.id = ?`;
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            db.query(upd_prod, id, function (err, result) {
                res.render('pages/admin_arrangementer_update', {
                    result: result
                });
            });
        }
    });

    // route til at opdatere(redigere) data'en der fetches med update.js filen
    app.put('/arr/update/:id', function (req, res) {
        var id = req.body.id
        var navn = req.body.navn
        var dato = req.body.dato
        var tekst = req.body.tekst
        var billede = req.body.billede

        db.query(`UPDATE arrangementer SET navn = ?, dato = ?, tekst = ?, billede = ? where id = ?`, [navn, dato, tekst, billede, id], (err) => {
            if (err) {
                console.log(err);
            } else {
                res.json(200);
            }
        })
    });


    // ====================================================================================================
    // ================================================ DELETE ============================================
    // ====================================================================================================


    // route til at slette produkter
    app.delete('/admin/admin_arrangementer', function (req, res) {
        var id = req.body.id;
        var sql = "delete FROM arrangementer where id = ?";
        db.query(sql, id, function (err, result) {
            if (err) {
                console.log(err)
            } else {
                res.sendStatus(200)
            }
        });
    });


}