// :: ROUTES TIL admin brugere siden

module.exports = (app) => {
    // route til at render admin medlemmer side
    app.get('/admin/admin_medlemmer', function (req, res) {
        // Er der logget ind?
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
            // Hvis der er logget ind render den siden
        } else {
            db.query(function (err) {
                res.render('pages/admin_medlemmer', {});
            });
        }
    });



    app.get('/admin/admin_medlemmer_signup', function (req, res) {
        // route til at render dashboard siden + spørg om brugeres session stadig er aktuel
        var user = req.session.user;
        var userId = req.session.userId;
        var userRole = req.session.userRole;
        // console.log(`Debug: Session.userID is ${userId}`);

        // findes session'en ikke sendes brugeren tilbage til login siden
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        }

        // henter alt data fra databasen omkring brugeren
        var sql = "SELECT * FROM users WHERE id = ?";
        // var bruger = "SELECT user_name FROM users WHERE id = ?";
        db.query(sql, [userId], function (err, results) {
            if (err) {
                console.log(err)
            } else {

                db.query(function (err) {
                    res.render('pages/admin_medlemmer_signup', {
                        user: user,
                        userRole: userRole
                    });
                });
            }
        });
    });











    // route til at render admin instruktør side
    app.get('/admin/admin_instruktoer', function (req, res) {
        // Er der logget ind?
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
            // Hvis der er logget ind render den siden
        } else {
            db.query(function (err) {
                res.render('pages/admin_instruktoer', {});
            });
        }
    });

}