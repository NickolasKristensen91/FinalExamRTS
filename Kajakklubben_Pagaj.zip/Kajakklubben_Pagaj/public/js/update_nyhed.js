// :: OPDATER PRODUKT FUNCTION - 

document.querySelector('#rediger').addEventListener('click', function () {
    var navn = document.querySelector('#arr_navn').value;
    var dato = document.querySelector('#arr_dato').value;
    var tekst = document.querySelector('#arr_tekst').value;
    var url = window.location.pathname;
    var id = url.substring(url.lastIndexOf('/') + 1);

    let fejl = "";

    if (navn == "") {
        fejl += "Angiv et navn. ";
        document.getElementById("arr_navn").style.borderColor = "#d9534f";
    } else {
        document.getElementById("arr_navn").style.borderColor = "#5cb85c";
    }

    if (arr_dato == "") {
        fejl += "Angiv en dato. ";
        document.getElementById("arr_dato").style.borderColor = "#d9534f";
    } else {
        if (isNaN(dato)) {
            fejl += "Dato skal være et tal. ";
            document.getElementById("arr_dato").style.borderColor = "#d9534f";
        } else {
            document.getElementById("arr_dato").style.borderColor = "#5cb85c";
        }
    }

    if (tekst == "") {
        fejl += "Tilføj en tekst. ";
        document.getElementById("arr_tekst").style.borderColor = "#d9534f";
    } else {
        document.getElementById("arr_tekst").style.borderColor = "#5cb85c";
    }

    if (fejl === "") {

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let init = {
            method: 'put',
            headers: headers,
            mode: 'cors',
            cache: 'no-cache',
            body: JSON.stringify({
                id: id,
                navn: navn,
                dato: dato,
                tekst: tekst,
            })
        };
        let request = new Request(url, init);
        console.log(`${id}`);
        fetch(request)
            .then(response => {
                if (response.status == 200) {
                    location.href = "/admin/admin_nyheder";
                    alert("Nyhed redigeret");
                } else {
                    throw new Error('Produkt blev ikke redigeret');
                    console.log(response.status)
                }
            }).catch(err => {
                console.log(err);
            });

    } else {
        alert(fejl);
    }
});