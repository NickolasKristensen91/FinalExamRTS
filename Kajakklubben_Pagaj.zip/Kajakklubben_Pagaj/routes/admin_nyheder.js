// :: ROUTES TIL admin nyheder siden

module.exports = (app) => {
    // ====================================================================================================
    // ================================================ RENDER ============================================
    // ====================================================================================================


    // route til at render admin nyheder side
    app.get('/admin/admin_nyheder', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var alle_nyheder = `SELECT nyheder.id, nyheder.navn, nyheder.dato, nyheder.tekst FROM nyheder`;
            db.query(alle_nyheder, function (err, allenyheder) {
                res.render('pages/admin_nyheder', {
                    allenyheder: allenyheder
                });
            });
        }
    });

    // route til at render admin nyheder oprettelses side
    app.get('/admin/admin_nyheder_opret', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var fejlbesked = ""
            var godkendtbesked = ""
            res.render('pages/admin_nyheder_opret', {
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
            console.log(fejlbesked)
        }
    });

    // ====================================================================================================
    // ================================================= POST =============================================
    // ====================================================================================================


    // route til at oprette en nyhed + Validering
    app.post('/admin_nyheder_opret', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        var alertopret = null
        var navn = req.body.navn
        var dato = req.body.dato
        var tekst = req.body.tekst

        // Validering
        if (navn == "" || dato == "" || tekst == "") {
            fejlbesked = "Formular ikke helt udfyldt!"
            res.render('pages/admin_nyheder_opret', {
                alertopret: alertopret,
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
        } else {
            db.query("insert into nyheder set navn = ?, dato = ?, tekst = ?", [navn, dato, tekst], (err) => {
                if (err) {
                    console.log(err)
                } else {
                    godkendtbesked = "Nyhed oprettet!"
                    res.render('pages/admin_nyheder_opret', {
                        fejlbesked: fejlbesked,
                        godkendtbesked: godkendtbesked
                    });

                }
            })

        }
    })


    // ====================================================================================================
    // ========================================== UPDATE / PUT ============================================
    // ====================================================================================================


    // route til at render update side og fetche en nyhed med et specifikt id via url 'en
    app.get('/admin/nyhed/update/:id', function (req, res) {
        var id = req.params.id
        var upd_prod = `SELECT nyheder.id, nyheder.navn, nyheder.dato, nyheder.tekst FROM nyheder where nyheder.id = ?`;
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            db.query(upd_prod, id, function (err, result) {
                res.render('pages/admin_nyheder_update', {
                    result: result
                });
            });
        }
    });

    // route til at opdatere(redigere) data 'en der fetches med update.js filen
    app.put('/admin/nyhed/update/:id', function (req, res) {
        var id = req.body.id
        var navn = req.body.navn
        var dato = req.body.dato
        var tekst = req.body.tekst

        db.query(`UPDATE nyheder SET navn = ?, dato = ?, tekst = ? where id = ?`, [navn, dato, tekst, id], (err) => {
            if (err) {
                console.log(err);
            } else {
                res.json(200);
            }
        })
    });


    // ====================================================================================================
    // ================================================ DELETE ============================================
    // ====================================================================================================


    // route til at slette nyheder
    app.delete('/admin/admin_nyheder', function (req, res) {
        var id = req.body.id;
        var sql = "delete FROM nyheder where id = ?";
        db.query(sql, id, function (err, result) {
            if (err) {
                console.log(err)
            } else {
                res.sendStatus(200)
            }
        });
    });


}