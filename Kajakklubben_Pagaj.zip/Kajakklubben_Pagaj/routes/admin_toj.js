// :: ROUTES TIL admin_toj side, opret_toj side & update side

module.exports = (app) => {
    // ====================================================================================================
    // ================================================ RENDER ============================================
    // ====================================================================================================


    // route til at render admin_toj side + select produkter fra database

    app.get('/admin/admin_toj', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var alt_toj = `SELECT tøj.id, tøj.navn, kategori.kategori_navn, tøj.maerke, tøj.pris, tøj.info, tøj.billede FROM tøj 
        INNER JOIN kategori ON tøj.fk_kategori = kategori.id`;
            db.query(alt_toj, function (err, alttoj) {
                // console.log(alttoj)
                res.render('pages/admin_toj', {
                    alttoj: alttoj
                });
            });
        }
    });


    // ====================================================================================================
    // ================================================ DELETE ============================================
    // ====================================================================================================


    // route til at slette produkter
    app.delete('/admin_toj', function (req, res) {
        var id = req.body.id;
        var sql = "delete FROM tøj where id = ?";
        db.query(sql, id, function (err, result) {
            if (err) {
                console.log(err)
            } else {
                res.sendStatus(200)
            }
        });
    });


    // ====================================================================================================
    // ========================================== UPDATE / PUT ============================================
    // ====================================================================================================


    // route til at render update side og fetche en cykel med et specifikt id via url'en
    app.get('/cykel/update/:id', function (req, res) {
        var id = req.params.id
        var alt_toj = "SELECT tøj.id, tøj.navn, kategori.kategori_navn, tøj.maerke, tøj.pris, tøj.info, tøj.billede, tøj.fk_kategori FROM tøj INNER JOIN kategori ON tøj.fk_kategori = kategori.id where tøj.id = ?";
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            db.query(alt_toj, id, function (err, result) {
                res.render('pages/update', {
                    result: result
                });
            });
        }
    });

    // route til at opdatere(redigere) data'en der fetches med update.js filen
    app.put('/update/:id', function (req, res) {
        var id = req.body.id
        var navn = req.body.navn
        var kategori = req.body.kategori;
        var maerke = req.body.maerke
        var pris = req.body.pris
        var info = req.body.info
        var img = req.body.billede
        db.query(`UPDATE tøj SET navn = ?, fk_kategori = ?, maerke = ?, pris = ?, info = ?, billede = ? where id = ?`, [navn, kategori, maerke, pris, info, img, id], (err, cykel) => {
            if (err) {
                console.log(err);
            } else {
                res.json(200);
            }
        })
    });


    // ====================================================================================================
    // ================================================= POST =============================================
    // ====================================================================================================


    // ==================== SKAL VÆRE UDKOMMENTERET!!! ELLERS DRILLER KONTAKT SIDEN =======================


    // route til at render "opret_toj" page
    // app.get('/opret_toj', function (req, res) {
    //     var userId = req.session.userId;
    //       if (userId == null || userRole != 'admin') {
    //         res.redirect("/login");
    //         return;
    //     } else {
    //         var fejlbesked = ""
    //         var godkendtbesked = ""
    //         res.render('pages/opret_toj', {
    //             fejlbesked: fejlbesked,
    //             godkendtbesked: godkendtbesked
    //         });
    //     }
    // });

    // // route til at oprette et produkt + Validering
    // app.post('/opret_toj', function (req, res) {
    //     var fejlbesked = ""
    //     var godkendtbesked = ""
    //     var alertopret = null
    //     var navn = req.body.navn
    //     var kategori = req.body.kategori
    //     var maerke = req.body.maerke
    //     var pris = req.body.pris
    //     var info = req.body.info
    //     var img = req.body.img

    //     // Validering
    //     if (navn == "" || kategori == "" || maerke == "" || pris == "" || info == "" || img == "") {
    //         fejlbesked = "Formular ikke helt udfyldt!"
    //         res.render('pages/opret_toj', {
    //             alertopret: alertopret,
    //             fejlbesked: fejlbesked,
    //             godkendtbesked: godkendtbesked
    //         });
    //     } else {
    //         db.query("insert into tøj set navn = ?, fk_kategori = ?, maerke = ?, pris = ?, info = ?, billede = ?", [navn, kategori, maerke, pris, info, img], (err, cykler) => {
    //             if (err) {
    //                 console.log(err)
    //             } else {
    //                 godkendtbesked = "Produkt oprettet!"
    //                 res.render('pages/opret_toj', {
    //                     fejlbesked: fejlbesked,
    //                     godkendtbesked: godkendtbesked
    //                 });

    //             }
    //         })

    //     }
    // })


    // ====================================================================================================
    // ============================================== SEARCH ==============================================
    // ====================================================================================================


    app.get('/search_value/:search', function (req, res) {
        var search = req.params.search;
        db.query(`select * from tøj where navn like '%${search}%' 
        or maerke like '%${search}%'
        or kategori like '%${search}%'`, search, (err, search) => {
            res.render('pages/search_value', {
                search: search
            })
            console.log(search)
        })
    })


}