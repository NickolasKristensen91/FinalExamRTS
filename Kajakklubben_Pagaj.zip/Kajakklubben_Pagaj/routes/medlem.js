// :: ROUTES TIL dashboard

module.exports = (app) => {

    app.get('/minside', function (req, res) {
        // route til at render dashboard siden + spørg om brugeres session stadig er aktuel
        var user = req.session.user;
        var userId = req.session.userId;
        var userRole = req.session.userRole;
        // console.log(`Debug: Session.userID is ${userId}`);

        // findes session'en ikke sendes brugeren tilbage til login siden
        if (userId == null || userRole != 'medlem') {
            res.redirect("/login");
            return;
        }

        // henter alt data fra databasen omkring brugeren
        var sql = "SELECT * FROM users WHERE id = ?";
        // var bruger = "SELECT user_name FROM users WHERE id = ?";
        db.query(sql, [userId], function (err, results) {
            if (err) {
                console.log(err)
            } else {

                db.query(function (err) {
                    res.render('pages/minside', {
                        user: user,
                        userRole: userRole
                    });
                });
            }
        });
    });



}