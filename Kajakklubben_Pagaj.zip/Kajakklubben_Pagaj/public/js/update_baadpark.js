// :: OPDATER PRODUKT FUNCTION - 

document.querySelector('#rediger').addEventListener('click', function () {
    var tekst = document.querySelector('#arr_tekst').value;
    var kategori = document.querySelector('#arr_kategori').value;
    var svaerhedsgrad = document.querySelector('#arr_svaerhedsgrad').value;
    var antal = document.querySelector('#arr_antal').value;
    var billede = document.querySelector('#arr_img').value;
    var url = window.location.pathname;
    var id = url.substring(url.lastIndexOf('/') + 1);

    let fejl = "";

    if (tekst == "") {
        fejl += "Angiv en beskrivelse. ";
        document.getElementById("arr_tekst").style.borderColor = "#d9534f";
    } else {
        document.getElementById("arr_tekst").style.borderColor = "#5cb85c";
    }

    if (kategori == "") {
        fejl += "Tildel produktet en kategori. ";
        document.getElementById("arr_kategori").style.borderColor = "#d9534f";
    } else {
        document.getElementById("arr_kategori").style.borderColor = "#5cb85c";
    }

    if (svaerhedsgrad == "") {
        fejl += "Tildel produktet en sværhedsgrad. ";
        document.getElementById("arr_svaerhedsgrad").style.borderColor = "#d9534f";
    } else {
        document.getElementById("arr_svaerhedsgrad").style.borderColor = "#5cb85c";
    }

    if (antal == "") {
        fejl += "Angiv en mængde. ";
        document.getElementById("arr_antal").style.borderColor = "#d9534f";
    } else {
        if (isNaN(antal)) {
            fejl += "Mængde skal være et tal. ";
            document.getElementById("arr_antal").style.borderColor = "#d9534f";
        } else {
            document.getElementById("arr_antal").style.borderColor = "#5cb85c";
        }
    }

    if (billede == "") {
        fejl += "Tilføj et billede. ";
        document.getElementById("arr_img").style.borderColor = "#d9534f";
    } else {
        document.getElementById("arr_img").style.borderColor = "#5cb85c";
    }

    if (fejl === "") {

        let headers = new Headers();
        headers.append('Content-Type', 'application/json');
        let init = {
            method: 'put',
            headers: headers,
            mode: 'cors',
            cache: 'no-cache',
            body: JSON.stringify({
                id: id,
                tekst: tekst,
                kategori: kategori,
                svaerhedsgrad: svaerhedsgrad,
                antal: antal,
                billede: billede

            })
        };
        let request = new Request(url, init);
        console.log(`${id}`);
        fetch(request)
            .then(response => {
                if (response.status == 200) {
                    location.href = "/admin/admin_baadpark";
                    alert("Produkt redigeret");
                } else {
                    throw new Error('Produkt blev ikke redigeret');
                    console.log(response.status)
                }
            }).catch(err => {
                console.log(err);
            });

    } else {
        alert(fejl);
    }
});