// :: ROUTES TIL sitets sider

module.exports = (app) => {

    // ====================================================================================================
    // ============================================= NYHEDER ==============================================
    // ====================================================================================================

    // route til at render nyheder side + fetch data fra db
    app.get('/nyheder', function (req, res) {
        var alle_nyheder = `SELECT nyheder.id, nyheder.navn, nyheder.dato, nyheder.tekst FROM nyheder`;
        db.query(alle_nyheder + " ORDER BY dato", function (err, alle_nyheder) {
            res.render('pages/nyheder', {
                alle_nyheder: alle_nyheder
            });

        });
    });

    // ====================================================================================================
    // ========================================== ARRANGEMENTER ===========================================
    // ====================================================================================================

    // route til at render arrangementer siden
    app.get('/arrangementer', function (req, res) {
        var alle_nyheder = `SELECT arrangementer.id, arrangementer.navn, arrangementer.dato, arrangementer.tekst, arrangementer.billede FROM arrangementer`;
        db.query(alle_nyheder, function (err, allearrs) {
            res.render('pages/arrangementer', {
                allearrs: allearrs
            });
        });
    });


    // ====================================================================================================
    // ============================================= GALLERI ==============================================
    // ====================================================================================================


    // route til at render galleri siden
    app.get('/galleri', function (req, res) {
        var alle_kategorier = `SELECT galleri_kategori.id, galleri_kategori.kategori_navn, galleri_kategori.billede FROM galleri_kategori`;
        db.query(alle_kategorier, function (err, allekategorier) {
            res.render('pages/galleri', {
                allekategorier: allekategorier
            });
        });
    });


    // ====================================================================================================
    // ============================================= BÅDPARK ==============================================
    // ====================================================================================================


    // route til at render bådpark siden
    app.get('/baadpark', function (req, res) {
        var alle_baade = `SELECT baadpark.id, baadtype_kategori.type, baadpark.svaerhedsgrad, baadpark.antal, baadpark.tekst, baadpark.billede FROM baadpark 
        INNER JOIN baadtype_kategori ON baadpark.fk_kategori = baadtype_kategori.id`;
        db.query(alle_baade, function (err, allebaade) {
            res.render('pages/baadpark', {
                allebaade: allebaade
            });
        });
    });

    // ====================================================================================================
    // ============================================= MEDLEM ===============================================
    // ====================================================================================================

    // route til at render Bliv Medlem siden
    app.get('/blivmedlem', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        db.query(function (err) {
            res.render('pages/blivmedlem', {
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
        });
    });


    // route til at tilmelde nyhedsbrev
    app.post('/blivmedlem', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        var alertopret = null
        var email = req.body.email

        // Validering
        if (email == "") {
            fejlbesked = "Indtast email for at modtage vores nyhedsbrev"
            res.render('pages/blivmedlem', {
                alertopret: alertopret,
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
        } else {
            db.query("insert into nyhedsbrev set email = ?", [email], (err, cykler) => {
                if (err) {
                    console.log(err)
                } else {
                    godkendtbesked = "Du er hermed tilmeldt vores nyhedsbrev"
                    res.render('pages/blivmedlem', {
                        fejlbesked: fejlbesked,
                        godkendtbesked: godkendtbesked
                    });

                }
            })

        }
    })


    // ====================================================================================================
    // ============================================= MIN SIDE =============================================
    // ====================================================================================================

    // route til at render Min Side siden
    app.get('/minside', function (req, res) {
        db.query(function (err) {
            res.render('pages/minside', {});
        });
    });

    // ====================================================================================================
    // ============================================= KONTAKT ==============================================
    // ====================================================================================================

    // route til at render "kontakt" page
    app.get('/kontakt', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        res.render('pages/kontakt', {
            fejlbesked: fejlbesked,
            godkendtbesked: godkendtbesked
        });
    });


    // route til at oprette en kontaktbesked + Validering
    app.post('/kontakt', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        var alertopret = null
        var navn = req.body.navn
        var email = req.body.email
        var tlf = req.body.tlf
        var besked = req.body.besked

        // Validering
        if (navn == "" || email == "" || besked == "") {
            fejlbesked = "Udfyld venligst navn, telefon nr. og beskedfelt"
            res.render('pages/kontakt', {
                alertopret: alertopret,
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
        } else {
            db.query("insert into kontakt_besked set navn = ?, email = ?, telefonnr = ?, besked = ?", [navn, email, tlf, besked], (err, cykler) => {
                if (err) {
                    console.log(err)
                } else {
                    godkendtbesked = "Tak for din besked :)"
                    res.render('pages/kontakt', {
                        fejlbesked: fejlbesked,
                        godkendtbesked: godkendtbesked
                    });

                }
            })

        }
    })

}