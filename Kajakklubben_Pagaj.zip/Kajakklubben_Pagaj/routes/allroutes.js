// :: ROUTES samlingspunkt til server

module.exports = function (app) {
    // Hjemmeside:
    require("./index")(app);
    require("./sitets_sider")(app);
    // Admin:
    require("./user")(app);
    require("./dashboard")(app);
    require("./admin_toj")(app);
    require("./admin_brugere")(app);
    require("./admin_galleri")(app);
    require("./admin_baadpark")(app);
    require("./admin_kontakt")(app);
    require("./admin_nyheder")(app);
    require("./admin_nyhedsbrev")(app);
    require("./admin_arrangementer")(app);

    // Medlem:
    require("./medlem")(app);

    // Instruktør:
    require("./instruktoer")(app);

    // require("./admin_baadpark_opret")(app);
    // require("./search_value")(app);
};