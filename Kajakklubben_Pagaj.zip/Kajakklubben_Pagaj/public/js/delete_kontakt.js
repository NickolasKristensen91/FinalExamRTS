// :: SLET PRODUKT FUNCTION - 

function del_arr(id) {
    var id = id
    var url = window.location.pathname;
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');

    let init = {
        method: 'delete',
        headers: headers,
        mode: 'cors',
        cache: 'no-cache',
        body: JSON.stringify({
            id: id
        })
    };
    let request = new Request(url, init);
    console.log(`${id}`);
    fetch(request)
        .then(response => {
            if (response.status == 200) {
                location.href = "/admin/admin_kontakt";
                alert("Kontaktbesked slettet!");
            } else {
                throw new Error('Produkt blev ikke slettet');
                console.log(response.status)
            }
        }).catch(err => {
            console.log(err);
        });


}