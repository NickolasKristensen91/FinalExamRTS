// :: ROUTES TIL admin galleri siden

module.exports = (app) => {
    // route til at render admin galleri side
    app.get('/admin/admin_galleri', function (req, res) {
        // Er der logget ind?
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
            // Hvis der er logget ind render denne siden
        } else {
            db.query(function (err) {
                res.render('pages/admin_galleri', {});
            });
        }
    });
}