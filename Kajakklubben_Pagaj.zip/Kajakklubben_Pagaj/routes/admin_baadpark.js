// :: ROUTES TIL admin bådpark siden

module.exports = (app) => {
    // ====================================================================================================
    // ================================================ RENDER ============================================
    // ====================================================================================================


    // route til at render admin bådpark side
    app.get('/admin/admin_baadpark', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin' && userRole != 'instruktoer') {
            res.redirect("/login");
            return;
        } else {
            var alle_baade = `SELECT baadpark.id, baadtype_kategori.type, baadpark.svaerhedsgrad, baadpark.antal, baadpark.tekst, baadpark.billede FROM baadpark 
            INNER JOIN baadtype_kategori ON baadpark.fk_kategori = baadtype_kategori.id`;
            db.query(alle_baade, function (err, allebaade) {
                res.render('pages/admin_baadpark', {
                    allebaade: allebaade
                });
            });
        }
    });

    // route til at render admin bådpark oprettelses side
    app.get('/admin/admin_baadpark_opret', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin' && userRole != 'instruktoer') {
            res.redirect("/login");
            return;
        } else {
            var fejlbesked = ""
            var godkendtbesked = ""
            res.render('pages/admin_baadpark_opret', {
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
            console.log(fejlbesked)
        }
    });

    // ====================================================================================================
    // ================================================= POST =============================================
    // ====================================================================================================


    // route til at oprette et produkt + Validering
    app.post('/admin_baadpark_opret', function (req, res) {
        var fejlbesked = ""
        var godkendtbesked = ""
        var alertopret = null
        var tekst = req.body.tekst
        var kategori = req.body.kategori
        var svaerhedsgrad = req.body.svaerhedsgrad
        var antal = req.body.antal
        var img = req.body.img

        // Validering
        if (tekst == "" || kategori == "" || svaerhedsgrad == "" || antal == "" || img == "") {
            fejlbesked = "Formular ikke helt udfyldt!"
            res.render('pages/admin_baadpark_opret', {
                alertopret: alertopret,
                fejlbesked: fejlbesked,
                godkendtbesked: godkendtbesked
            });
        } else {
            db.query("insert into baadpark set tekst = ?, fk_kategori = ?, svaerhedsgrad = ?, antal = ?, billede = ?", [tekst, kategori, svaerhedsgrad, antal, img], (err, cykler) => {
                if (err) {
                    console.log(err)
                } else {
                    godkendtbesked = "Produkt oprettet!"
                    res.render('pages/admin_baadpark_opret', {
                        fejlbesked: fejlbesked,
                        godkendtbesked: godkendtbesked
                    });

                }
            })

        }
    })


    // ====================================================================================================
    // ========================================== UPDATE / PUT ============================================
    // ====================================================================================================


    // route til at render update side og fetche et produkt med et specifikt id via url'en
    app.get('/admin/baad/update/:id', function (req, res) {
        var id = req.params.id
        var upd_prod = `SELECT baadpark.id, baadpark.tekst, baadtype_kategori.type, baadpark.svaerhedsgrad, baadpark.antal, baadpark.billede, baadpark.fk_kategori FROM baadpark 
        INNER JOIN baadtype_kategori ON baadpark.fk_kategori = baadtype_kategori.id where baadpark.id = ?`;
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin' && userRole != 'instruktoer') {
            res.redirect("/login");
            return;
        } else {
            db.query(upd_prod, id, function (err, result) {
                res.render('pages/admin_baadpark_update', {
                    result: result
                });
            });
        }
    });

    // route til at opdatere(redigere) data'en der fetches med update.js filen
    app.put('/admin/baad/update/:id', function (req, res) {
        var id = req.body.id
        var tekst = req.body.tekst
        var kategori = req.body.kategori
        var svaerhedsgrad = req.body.svaerhedsgrad
        var antal = req.body.antal
        var img = req.body.billede
        // var img = req.body.billede

        db.query(`UPDATE baadpark SET tekst = ?, fk_kategori = ?, svaerhedsgrad = ?, antal = ?, billede = ? where id = ?`, [tekst, kategori, svaerhedsgrad, antal, img, id], (err, cykel) => {
            if (err) {
                console.log(err);
            } else {
                res.json(200);
            }
        })
    });


    // ====================================================================================================
    // ================================================ DELETE ============================================
    // ====================================================================================================


    // route til at slette produkter
    app.delete('/admin/admin_baadpark', function (req, res) {
        var id = req.body.id;
        var sql = "delete FROM baadpark where id = ?";
        db.query(sql, id, function (err, result) {
            if (err) {
                console.log(err)
            } else {
                res.sendStatus(200)
            }
        });
    });


}