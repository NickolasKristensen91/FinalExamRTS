function soeg() {
    var soegefelt = document.getElementById("soegefelt").value;
    window.location.replace(`/sogeresultat/${soegefelt}`)
}