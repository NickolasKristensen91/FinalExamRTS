// :: ROUTES TIL admin kontakt siden

module.exports = (app) => {
    // ====================================================================================================
    // ================================================ RENDER ============================================
    // ====================================================================================================


    // route til at render admin bådpark side
    app.get('/admin/admin_kontakt', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var alle_beskeder = `SELECT kontakt_besked.id, kontakt_besked.navn, kontakt_besked.email, kontakt_besked.telefonnr, kontakt_besked.besked FROM kontakt_besked`;
            db.query(alle_beskeder, function (err, allebeskeder) {
                res.render('pages/admin_kontakt', {
                    allebeskeder: allebeskeder
                });
            });
        }
    });


    // ====================================================================================================
    // ================================================ DELETE ============================================
    // ====================================================================================================


    // route til at slette produkter
    app.delete('/admin/admin_kontakt', function (req, res) {
        var id = req.body.id;
        var sql = "delete FROM kontakt_besked where id = ?";
        db.query(sql, id, function (err, result) {
            if (err) {
                console.log(err)
            } else {
                res.sendStatus(200)
            }
        });
    });


}