// :: ROUTES TIL admin nyhedsbrev siden

module.exports = (app) => {
    // ====================================================================================================
    // ================================================ RENDER ============================================
    // ====================================================================================================


    // route til at render admin bådpark side
    app.get('/admin/admin_nyhedsbrev', function (req, res) {
        var userId = req.session.userId;
        var userRole = req.session.userRole
        if (userId == null || userRole != 'admin') {
            res.redirect("/login");
            return;
        } else {
            var alle_breve = `SELECT nyhedsbrev.id, nyhedsbrev.email FROM nyhedsbrev`;
            db.query(alle_breve, function (err, allebreve) {
                res.render('pages/admin_nyhedsbrev', {
                    allebreve: allebreve
                });
            });
        }
    });

}